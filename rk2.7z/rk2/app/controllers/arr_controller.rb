# frozen_string_literal: true

def find_max(supr, line)
  max_val = 0
  ind = []
  (0..(supr / 2 - 1)).each do |i|
    arg = line[i].to_i / line[supr / 2 + i].to_i
    if arg > max_val
      max_val = arg
      ind = [i, supr / 2 + i]
    end
  end
  [max_val, ind]
end

def aa(arr)
  v1 = arr
  n = v1.size
  find_max(n, v1)
end

# дадада
class ArrController < ApplicationController
  def input
    @default = '50 1 2 5'
  end

  def view
    v = params[:a].split(' ')
    @arra = params[:a].to_s
    @result = aa(v).to_s
  end
end
