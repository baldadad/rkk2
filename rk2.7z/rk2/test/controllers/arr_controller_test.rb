require "test_helper"

class ArrControllerTest < ActionDispatch::IntegrationTest
  test "should get input" do
    get arr_input_url
    assert_response :success
  end

  test "should get view" do
    get arr_view_url
    assert_response :success
  end
end
